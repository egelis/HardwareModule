var searchData=
[
  ['subscription_20example_699',['Subscription example',['../subscribe.html',1,'']]],
  ['subscription_20wildcards_700',['Subscription wildcards',['../wildcard.html',1,'']]]
];
